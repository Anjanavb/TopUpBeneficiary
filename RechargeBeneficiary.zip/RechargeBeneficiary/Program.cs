using Microsoft.EntityFrameworkCore;
using RechargeBeneficiary.Data;
using RechargeBeneficiary.Data.Repository;
using RechargeBeneficiary.ExternalServices;
var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers().AddNewtonsoftJson(options =>
{
    options.SerializerSettings.ReferenceLoopHandling=Newtonsoft.Json.ReferenceLoopHandling.Ignore;
});
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddScoped<ICustomerRepository, CustomerRepository>();
builder.Services.AddScoped<IBeneficiaryRepository, BeneficiaryRepository>();
builder.Services.AddScoped<ITopupOptionRepository, TopupRepository>();
builder.Services.AddScoped<ITopupTransactionRepository, TopupTransactionRepository>();
builder.Services.AddScoped<IExternalBalanceAPIService, ExternalBalanceAPIService>();
builder.Services.AddAutoMapper(typeof(Program));
builder.Services.AddDbContext<TopUpDBContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("TopUpSystemDbContext") ?? throw new InvalidOperationException("Connection string 'RechargeSystemDbContext' not found.")));
builder.Services.AddHttpClient();
var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
