﻿using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using RechargeBeneficiary.Data.Repository;

namespace RechargeBeneficiary.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private readonly IMapper _mapper;
        private readonly ICustomerRepository _customerRepository;
        public CustomerController(ICustomerRepository customerRepository, IMapper mapper)
        {
            _customerRepository = customerRepository;
            _mapper = mapper;
        }
        [HttpGet("GetAllCustomer")]
        public async Task<IActionResult> GetCustomers()
        {
            var customers = await _customerRepository.GetAll();
            return Ok(customers);
        }

        //[HttpGet("{id:int}", Name = "GetCustomerByID")]
        //public async Task<IActionResult> GetCustomerById(int id)
        //{
        //    var customers = await _customerRepository.GetById(id);
        //    return Ok(customers);
        //}

        //[HttpPost("CreateCustomer")]
        //public async Task<IActionResult> CreateCustomer(CustomerDto customerDto)
        //{
        //    if (customerDto == null)
        //        return BadRequest();
        //    var customer = _mapper.Map<Customer>(customerDto);
        //    var newCustomer = await _customerRepository.CreateCustomer(customer);
        //    return CreatedAtRoute("GetCustomerById", new { id = newCustomer.CustomerID }, customerDto);
        //}
    }
}
