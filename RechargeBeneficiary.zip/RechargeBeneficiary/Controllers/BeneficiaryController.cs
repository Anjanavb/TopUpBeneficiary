﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RechargeBeneficiary.Data.Dto;
using RechargeBeneficiary.Data.Repository;
using RechargeBeneficiary.Model;

namespace RechargeBeneficiary.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BeneficiaryController : ControllerBase
    {
        private readonly IBeneficiaryRepository _beneficiaryRepository;
        private readonly ICustomerRepository _customerRepository;
        private readonly IMapper _mapper;
        public BeneficiaryController(IBeneficiaryRepository beneficiaryRepository,
                        ICustomerRepository customerRepository,
                        IMapper mapper)
        {
            _beneficiaryRepository = beneficiaryRepository;
            _customerRepository = customerRepository;
            _mapper = mapper;
        }

        [HttpGet("GetAllBeneficiaries")]
        public async Task<IActionResult> GetBeneficiaries(int customerID)
        {
            try
            {
                if (customerID <= 0)
                {
                    return BadRequest("Invalid customer ID.");
                }
                var beneficiaries = await _beneficiaryRepository.GetAllBeneficiary(customerID);
                if (beneficiaries == null || !beneficiaries.Any())
                {
                    return NotFound("No beneficiaries found for the provided customer ID.");
                }
                var beneficiaryDtoList = beneficiaries.Select(item => _mapper.Map<BeneficiaryDto>(item)).ToList();

                return Ok(beneficiaryDtoList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while processing your request.");
            }
        }

        [HttpPost("CreateBeneficiary")]
        public async Task<IActionResult> CreateBeneficiary(CreateBeneficaryDto beneficiaryDto)
        {
            try
            {
                //validations
                if (beneficiaryDto == null)
                    return BadRequest(new { Message = "Beneficiary data is required." });
                if (beneficiaryDto.CustomerID <= 0)
                    return BadRequest(new { Message = "Invalid CustomerID. It must be greater than 0." });
                if (! await _customerRepository.IsValidCustomer(beneficiaryDto.CustomerID))
                    return BadRequest(new { Message = "Customer doesnt exist." });
                if (await _beneficiaryRepository.GetActiveBeneficiariesCount(beneficiaryDto.CustomerID) >= 5)
                {
                    return Conflict(new { Message = "The customer has reached the maximum number of active beneficiaries." });
                }
                if (await _beneficiaryRepository.IsBeneficiaryPhNumberExist(beneficiaryDto.PhoneNumber, beneficiaryDto.CustomerID))
                {
                    return Conflict(new { Message = "Beneficiary with same phone number exist." });
                }
                //mapping
                var beneficiary = _mapper.Map<Beneficiary>(beneficiaryDto);
                //create
                await _beneficiaryRepository.CreateBeneficiary(beneficiary);
                beneficiaryDto.CustomerID = beneficiary.CustomerID;
                return CreatedAtAction("GetBeneficiaries", new { id = beneficiary.BeneficiaryID }, beneficiary);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { Message = "Invalid argument: " + ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(new { Message = "Operation failed: " + ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = "An error occurred while processing your request." });
            }


        }
    }
}
