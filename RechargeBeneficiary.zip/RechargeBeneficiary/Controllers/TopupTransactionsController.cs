﻿using System;
using Microsoft.AspNetCore.Mvc;
using RechargeBeneficiary.Model;
using RechargeBeneficiary.Data.Dto;
using AutoMapper;
using RechargeBeneficiary.Data.Repository;
using RechargeBeneficiary.ExternalServices;

namespace RechargeBeneficiary.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TopupTransactionsController : ControllerBase
    {
        private readonly ITopupTransactionRepository _transactionRepository;
        private readonly ICustomerRepository _customerRepository;
        private readonly IBeneficiaryRepository _beneficiaryRepository;
        private readonly ITopupOptionRepository _topupOptionRepository;
        private readonly IMapper _mapper;
        private readonly IExternalBalanceAPIService _externalBalanceAPIService;

        public TopupTransactionsController(ITopupTransactionRepository transactionRepository,
            ICustomerRepository customerRepository, IBeneficiaryRepository beneficiaryRepository,
            ITopupOptionRepository topupOptionRepository, IMapper mapper,
             IExternalBalanceAPIService externalBalanceAPIService)
        {
            _transactionRepository = transactionRepository;
            _customerRepository = customerRepository;
            _beneficiaryRepository = beneficiaryRepository;
            _topupOptionRepository = topupOptionRepository;
            _mapper = mapper;
            _externalBalanceAPIService = externalBalanceAPIService;
        }

        [HttpPost("TopupBeneficiary")]
        public async Task<ActionResult<TransactionResponseDto>> CreateTransactionAsync(TopupTransactionDto topupTransactionDto)
        {
            var additionalCharge = 1.00m;
            try
            {
                // Load related entities
                var topupOption = await _topupOptionRepository.GetTopupOptionsById(topupTransactionDto.TopupOptionID);
                var customer = await _customerRepository.GetById(topupTransactionDto.CustomerID);
                var beneficiary = await _beneficiaryRepository.GetBeneficiaryById(topupTransactionDto.BeneficiaryID);

                if (topupOption == null)
                    return BadRequest("Invalid top-up option provided.");

                if (customer == null)
                    return BadRequest("Invalid customer provided.");

                if (beneficiary == null)
                    return BadRequest("Invalid beneficiary provided.");

                //Get total amount recharged per beneficiary for current month
                var totalAmountforMonthForBeneficiary = _transactionRepository.TotalRechargeAmountForMonthByBeneficiaryID(topupTransactionDto.CustomerID, topupTransactionDto.BeneficiaryID);
                var totalAmountforCurrentTransaction = topupOption.Value + additionalCharge;
                // Validation : max recharge amount for beneficiary
                if (await _customerRepository.IsVerifiedCustomer(topupTransactionDto.CustomerID))
                {
                    //  Validation : total amount so far for beneficiary +  current toptup + additional 1 aed) > max limit
                    if (await totalAmountforMonthForBeneficiary + totalAmountforCurrentTransaction > 500)
                    {
                        return BadRequest("Recharge limit exceeded for this beneficiary this month.");
                    }
                }
                else
                {
                    //  Validation : total amount so far for beneficiary + add current toptup + additional 1 aed > max limit
                    if (await totalAmountforMonthForBeneficiary + totalAmountforCurrentTransaction > 1000)
                    {
                        return BadRequest("Recharge limit exceeded for this beneficiary this month.");
                    }
                }
                //total recharge per month will be 3000 max
                // Validation : total amount so far + add current toptup +additional 1 aed > max limit
                var totalTransactionForCurrentMonth = await _transactionRepository.TotalRechargeAmountForMonth(topupTransactionDto.CustomerID);
                if (totalTransactionForCurrentMonth + totalAmountforCurrentTransaction >= 3000)
                {
                    var remainingAllowedAmount = 3000 - totalTransactionForCurrentMonth;
                    if (remainingAllowedAmount < 5)
                    {
                        return BadRequest("Oops! Your transaction amount is higher than the allowed limit of 3000 AED for this month.Please try next month");
                    }
                    return BadRequest("Oops! Your transaction amount is higher than the allowed limit of 3000 AED for this month. Please enter a lower amount below "+ remainingAllowedAmount+" and try again");

                }
                //get the balance amount from external API
                var availableBalance = await _externalBalanceAPIService.GetAccountBalanceAsync(customer.AccountID);
                // Validation : 
                if (availableBalance < totalAmountforCurrentTransaction)
                {
                    return BadRequest("Insufficient balance for this topup");
                }

                //debit balance amount using external API
                var result = await _externalBalanceAPIService.DebitAccountAsync(customer.AccountID, totalAmountforCurrentTransaction);
                if (result == "Debit successful")
                {
                    var transaction = new TopupTransaction
                    {
                        TopupOptionID = topupTransactionDto.TopupOptionID,
                        CustomerID = topupTransactionDto.CustomerID,
                        BeneficiaryID = topupTransactionDto.BeneficiaryID,
                        TopupOption = topupOption,
                        Customer = customer,
                        Beneficiary = beneficiary,
                        TotalAmount = totalAmountforCurrentTransaction,
                        Status = "Success"
                    };
                    //insert to transaction table
                    var response = await _transactionRepository.PostTopupTransaction(transaction);
                    return Ok(response);
                }
                else
                {
                    return StatusCode(500, new { Message = "Debit failed, unexpected response from external API." });
                }
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }    
}
