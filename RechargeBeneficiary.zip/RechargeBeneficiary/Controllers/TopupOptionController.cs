﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RechargeBeneficiary.Data;
using RechargeBeneficiary.Data.Dto;
using RechargeBeneficiary.Data.Repository;
using RechargeBeneficiary.Model;

namespace RechargeBeneficiary.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TopupOptionController : ControllerBase
    {
        private readonly IMapper _mapper;
        private readonly ITopupOptionRepository _topupOptionRepository;

        public TopupOptionController(ITopupOptionRepository topupOptionRepository, IMapper mapper)
        {
            _mapper = mapper;
            _topupOptionRepository = topupOptionRepository;
        }

        [HttpGet("GetAllTopupOptions")]
        public async Task<ActionResult> GetTopupOptions()
        {
            try
            {
                var topupOptionDtoList = new List<TopupOptionDto>();
                var topupOptions = await _topupOptionRepository.GetTopupOptions();
                foreach (var item in topupOptions)
                {
                    var topupOptionDto = _mapper.Map<TopupOptionDto>(item);
                    topupOptionDtoList.Add(topupOptionDto);
                }
                return Ok(topupOptionDtoList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = "An error occurred while retrieving topup options. Please try again later." });
            }
            
        }
    }
}
