﻿namespace RechargeBeneficiary.ExternalServices
{
    public interface IExternalBalanceAPIService
    {
        Task<decimal> GetAccountBalanceAsync(int AccountID);
        Task<string> DebitAccountAsync(int accountId, decimal amount);
    }
}
