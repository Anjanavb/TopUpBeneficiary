﻿using System.Text;
using System.Text.Json;
using Azure;
using Microsoft.Identity.Client;
using RechargeBeneficiary.Model;
using RechargeBeneficiary.Model.ExternalAPI;

namespace RechargeBeneficiary.ExternalServices
{
    public class ExternalBalanceAPIService : IExternalBalanceAPIService
    {
        private readonly HttpClient _httpClient;
        private readonly string _baseUrl;
        private readonly string _getBalanceEndpoint;
        public ExternalBalanceAPIService(HttpClient httpClient, IConfiguration configuration)
        {
            _httpClient = httpClient;
            _baseUrl = configuration["ApiSettings:BaseUrl"];
            _getBalanceEndpoint = configuration["ApiSettings:GetAccountBalanceEndpoint"];
        }

        public async Task<decimal> GetAccountBalanceAsync(int accountID)
        {
            try
            {
                var requestUrl = $"{_baseUrl}{_getBalanceEndpoint}";
                requestUrl = requestUrl+ $"?accountId={accountID}";
                var response = await _httpClient.GetAsync(requestUrl);
                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception($"Error retrieving balance: {response.ReasonPhrase}");
                }

                var responseData = await response.Content.ReadAsStringAsync();
                var balanceResponse = JsonSerializer.Deserialize<AccountBalanceResponse>(responseData, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true // Optional: if JSON property names might have different casing
                });
                return balanceResponse?.AccountBalance ?? throw new Exception("Error deserializing balance response.");
            }

            catch (HttpRequestException ex)
            {
                throw new Exception("Error retrieving balance from external API.", ex);
            }
        }
        public async Task<string> DebitAccountAsync(int accountId, decimal amount)
        {
            var requestUrl = $"https://localhost:7206/api/AccountBalance/debit";
            var debitRequest = new DebitRequest
            {
                AccountId = accountId,
                Amount = amount
            };

            try
            {
                // Serialize the request payload to JSON
                var jsonContent = JsonSerializer.Serialize(debitRequest);
                var content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

                // Send the POST request
                var response = await _httpClient.PostAsync(requestUrl, content);
                response.EnsureSuccessStatusCode(); 

                // Read and return the response content
                var responseData = await response.Content.ReadAsStringAsync();
                return responseData; 
            }
            catch (HttpRequestException ex)
            {
                // Log or handle the exception
                throw new Exception("Error calling the external debit API.", ex);
            }
        }
    }
}
