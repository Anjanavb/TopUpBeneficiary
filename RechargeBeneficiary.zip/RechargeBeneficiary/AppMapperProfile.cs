﻿using AutoMapper;
using RechargeBeneficiary.Data.Dto;
using RechargeBeneficiary.Model;
namespace RechargeBeneficiary
{
    public class AppMapperProfile : Profile
    {
        public AppMapperProfile()
        {
            CreateMap<CustomerDto, Customer>();
            CreateMap<BeneficiaryDto, Beneficiary>();
            CreateMap<Beneficiary, BeneficiaryDto>();
            CreateMap<Beneficiary, CreateBeneficaryDto>().ReverseMap();
            CreateMap<TopupOption, TopupOptionDto>();
            CreateMap<TopupTransaction, TopupOptionDto>()
           .ForMember(dest => dest.Value, opt => opt.MapFrom(src => src.TopupOption.Value));


            CreateMap<TopupTransactionDto, TopupTransaction>()
           .ForMember(dest => dest.TopupOption, opt => opt.Ignore())  // Ignore navigation properties
           .ForMember(dest => dest.Customer, opt => opt.Ignore())
           .ForMember(dest => dest.Beneficiary, opt => opt.Ignore());

           // CreateMap<TopupTransactionDto, TopupTransaction>();

        }
    }
}
