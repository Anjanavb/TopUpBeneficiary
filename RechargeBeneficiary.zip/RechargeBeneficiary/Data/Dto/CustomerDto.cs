﻿using RechargeBeneficiary.Model;
using System.ComponentModel.DataAnnotations;

namespace RechargeBeneficiary.Data.Dto
{
    public class CustomerDto
    {
        [Required(ErrorMessage = "Customer Name is required.")]
        public string CustomerName { get; set; }
        [Required(ErrorMessage = "PhoneNumber is required.")]
        [RegularExpression(@"^\+?[1-9]\d{1,14}$", ErrorMessage = "PhoneNumber is not in a valid format.")]
        public string PhoneNumber { get; set; }
        public bool IsVerified { get; set; }
        public List<CreateBeneficaryDto> Beneficiaries { get; set; }
    }
}
