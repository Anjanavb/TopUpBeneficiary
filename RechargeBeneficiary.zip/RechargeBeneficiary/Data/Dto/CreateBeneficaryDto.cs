﻿using System.ComponentModel.DataAnnotations;

namespace RechargeBeneficiary.Data.Dto
{
    public class CreateBeneficaryDto
    {
        [Required(ErrorMessage = "BeneficiaryName is required.")]
        [MaxLength(20, ErrorMessage = "BeneficiaryName cannot be longer than 20 characters.")]
        public string BeneficiaryName { get; set; }

        [Required(ErrorMessage = "PhoneNumber is required.")]
        [RegularExpression(@"^\+?[1-9]\d{1,14}$", ErrorMessage = "PhoneNumber is not in a valid format.")]
        public string PhoneNumber { get; set; }
        [Required(ErrorMessage = "CustomerID is required.")]
        public int CustomerID { get; set; }
    }
}
