﻿namespace RechargeBeneficiary.Data.Dto
{
    public class TopupOptionDto
    {
        public int TopupOptionId { get; set; }
        public string OptionName { get; set; }
        public decimal Value { get; set; }
    }
}
