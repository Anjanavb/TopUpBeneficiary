﻿using RechargeBeneficiary.Model;

namespace RechargeBeneficiary.Data.Dto
{
    public class BeneficiaryDto
    {
        public int BeneficiaryID { get; set; }
        public string BeneficiaryName { get; set; }
        public string PhoneNumber { get; set; }
        public int CustomerID { get; set; }
    }
}
