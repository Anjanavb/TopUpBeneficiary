﻿namespace RechargeBeneficiary.Data.Dto
{
    public class TopupTransactionDto
    {
        public int TopupOptionID { get; set; }
        public int CustomerID { get; set; }
        public int BeneficiaryID { get; set; }
    }
}
