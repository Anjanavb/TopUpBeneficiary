﻿using Microsoft.EntityFrameworkCore;
using RechargeBeneficiary.Model;

namespace RechargeBeneficiary.Data
{
    public class TopUpDBContext : DbContext
    {
        public TopUpDBContext(DbContextOptions<TopUpDBContext> options) : base(options)
        {

        }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Beneficiary> Beneficiaries { get; set; }
        public DbSet<TopupOption> TopupOptions { get; set; }
        public DbSet<TopupTransaction> TopupTransactions  { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Customer>().HasData(new List<Customer>
           {
               new Customer { CustomerID = 1 , CustomerName="CustomerA",PhoneNumber="971100000000",AccountID=1,IsVerified=true},
               new Customer { CustomerID = 2 , CustomerName="CustomerB",PhoneNumber="9712000000000",AccountID=2,IsVerified=true},
               new Customer { CustomerID = 3 , CustomerName="CustomerC",PhoneNumber="9713000000000",AccountID=3,IsVerified=true},
               new Customer { CustomerID = 4 , CustomerName="CustomerD",PhoneNumber="9714000000000",AccountID=4,IsVerified=true},
               new Customer { CustomerID = 5 , CustomerName="CustomerE",PhoneNumber="9715000000000",AccountID=5,IsVerified=false},
               new Customer { CustomerID = 6 , CustomerName="CustomerF",PhoneNumber="9716000000000",AccountID=6,IsVerified=false}
           });
            modelBuilder.Entity<Beneficiary>().HasData(new List<Beneficiary>
           {
               new Beneficiary { BeneficiaryID=1, BeneficiaryName="BeneficiaryA1",PhoneNumber="971000000001",IsActive=true,CustomerID=1},
               new Beneficiary { BeneficiaryID=2, BeneficiaryName="BeneficiaryB1",PhoneNumber="972000000001",IsActive=true,CustomerID=2},
               new Beneficiary { BeneficiaryID=3, BeneficiaryName="BeneficiaryB2",PhoneNumber="972000000002",IsActive=true,CustomerID=2},
               new Beneficiary { BeneficiaryID=4, BeneficiaryName="BeneficiaryB3",PhoneNumber="972000000003",IsActive=true,CustomerID=2},
               new Beneficiary { BeneficiaryID=5, BeneficiaryName="BeneficiaryB4",PhoneNumber="972000000004",IsActive=true,CustomerID=2},
               new Beneficiary { BeneficiaryID=6, BeneficiaryName="BeneficiaryB5",PhoneNumber="972000000005",IsActive=true,CustomerID=2},
               new Beneficiary { BeneficiaryID=7, BeneficiaryName="BeneficiaryC1",PhoneNumber="973000000001",IsActive=true,CustomerID=3},
               new Beneficiary { BeneficiaryID=8, BeneficiaryName="BeneficiaryD1",PhoneNumber="974000000001",IsActive=true,CustomerID=4},
               new Beneficiary { BeneficiaryID=9, BeneficiaryName="BeneficiaryD2",PhoneNumber="974000000002",IsActive=true,CustomerID=4},
               new Beneficiary { BeneficiaryID=10, BeneficiaryName="BeneficiaryE1",PhoneNumber="975000000001",IsActive=true,CustomerID=5},
               new Beneficiary { BeneficiaryID=11, BeneficiaryName="BeneficiaryF1",PhoneNumber="976000000001",IsActive=true,CustomerID=6},
               new Beneficiary { BeneficiaryID=12, BeneficiaryName="BeneficiaryF2",PhoneNumber="976000000002",IsActive=true,CustomerID=6},
               new Beneficiary { BeneficiaryID=13, BeneficiaryName="BeneficiaryF3",PhoneNumber="976000000003",IsActive=true,CustomerID=6},
               new Beneficiary { BeneficiaryID=14, BeneficiaryName="BeneficiaryF4",PhoneNumber="976000000004",IsActive=true,CustomerID=6},
               new Beneficiary { BeneficiaryID=15, BeneficiaryName="BeneficiaryF5",PhoneNumber="976000000005",IsActive=true,CustomerID=6}
            });
            modelBuilder.Entity<TopupOption>().HasData(new List<TopupOption>
           {
               new TopupOption { TopupOptionId=1, OptionName="AED 5",Value=5},
               new TopupOption { TopupOptionId=2, OptionName="AED 10",Value=10},
               new TopupOption { TopupOptionId=3, OptionName="AED 20",Value=20},
               new TopupOption { TopupOptionId=4, OptionName="AED 30",Value=30},
               new TopupOption { TopupOptionId=5, OptionName="AED 50",Value=50},
               new TopupOption { TopupOptionId=6, OptionName="AED 75",Value=75},
               new TopupOption { TopupOptionId=7, OptionName="AED 100",Value=100 }
           });
            modelBuilder.Entity<TopupTransaction>().HasData(new List<TopupTransaction>
           {
               new TopupTransaction {TransactionId=1,TopupOptionID=7,CustomerID=4,BeneficiaryID=8,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=2,TopupOptionID=7,CustomerID=4,BeneficiaryID=8,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=3,TopupOptionID=7,CustomerID=4,BeneficiaryID=8,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=4,TopupOptionID=7,CustomerID=4,BeneficiaryID=8,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },

               new TopupTransaction {TransactionId=5,TopupOptionID=7,CustomerID=5,BeneficiaryID=10,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=6,TopupOptionID=7,CustomerID=5,BeneficiaryID=10,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=7,TopupOptionID=7,CustomerID=5,BeneficiaryID=10,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=8,TopupOptionID=7,CustomerID=5,BeneficiaryID=10,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=9,TopupOptionID=7,CustomerID=5,BeneficiaryID=10,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=10,TopupOptionID=7,CustomerID=5,BeneficiaryID=10,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=11,TopupOptionID=7,CustomerID=5,BeneficiaryID=10,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=12,TopupOptionID=7,CustomerID=5,BeneficiaryID=10,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=13,TopupOptionID=7,CustomerID=5,BeneficiaryID=10,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=14,TopupOptionID=5,CustomerID=5,BeneficiaryID=10,TotalAmount=51,TransactionDate=DateTime.UtcNow,Status="Success" },

               new TopupTransaction {TransactionId=15,TopupOptionID=7,CustomerID=6,BeneficiaryID=11,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=16,TopupOptionID=7,CustomerID=6,BeneficiaryID=11,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=17,TopupOptionID=7,CustomerID=6,BeneficiaryID=11,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=18,TopupOptionID=7,CustomerID=6,BeneficiaryID=11,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=19,TopupOptionID=7,CustomerID=6,BeneficiaryID=11,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=20,TopupOptionID=7,CustomerID=6,BeneficiaryID=11,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=21,TopupOptionID=7,CustomerID=6,BeneficiaryID=11,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=22,TopupOptionID=7,CustomerID=6,BeneficiaryID=11,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=23,TopupOptionID=7,CustomerID=6,BeneficiaryID=11,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=24,TopupOptionID=7,CustomerID=6,BeneficiaryID=12,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=25,TopupOptionID=7,CustomerID=6,BeneficiaryID=12,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=26,TopupOptionID=7,CustomerID=6,BeneficiaryID=12,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=27,TopupOptionID=7,CustomerID=6,BeneficiaryID=12,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=28,TopupOptionID=7,CustomerID=6,BeneficiaryID=12,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=29,TopupOptionID=7,CustomerID=6,BeneficiaryID=12,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=30,TopupOptionID=7,CustomerID=6,BeneficiaryID=12,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=31,TopupOptionID=7,CustomerID=6,BeneficiaryID=12,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=32,TopupOptionID=7,CustomerID=6,BeneficiaryID=12,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=33,TopupOptionID=7,CustomerID=6,BeneficiaryID=13,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=34,TopupOptionID=7,CustomerID=6,BeneficiaryID=13,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=35,TopupOptionID=7,CustomerID=6,BeneficiaryID=13,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=36,TopupOptionID=7,CustomerID=6,BeneficiaryID=13,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=37,TopupOptionID=7,CustomerID=6,BeneficiaryID=13,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=38,TopupOptionID=7,CustomerID=6,BeneficiaryID=13,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=39,TopupOptionID=7,CustomerID=6,BeneficiaryID=13,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=40,TopupOptionID=7,CustomerID=6,BeneficiaryID=13,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=41,TopupOptionID=7,CustomerID=6,BeneficiaryID=13,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=42,TopupOptionID=7,CustomerID=6,BeneficiaryID=14,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=43,TopupOptionID=7,CustomerID=6,BeneficiaryID=14,TotalAmount=101,TransactionDate=DateTime.UtcNow,Status="Success" },
               new TopupTransaction {TransactionId=44,TopupOptionID=5,CustomerID=6,BeneficiaryID=14,TotalAmount=51,TransactionDate=DateTime.UtcNow,Status="Success" }

           });

            //Customer Table
            modelBuilder.Entity<Customer>(entity =>
            {
                entity.HasKey(c => c.CustomerID);
                entity.Property(c => c.CustomerName)
                    .IsRequired() 
                    .HasMaxLength(200);
                entity.Property(c => c.PhoneNumber)
                    .IsRequired()
                    .HasMaxLength(15);
                entity.Property(c => c.IsVerified)
                    .IsRequired();
                entity.Property(c => c.AccountID)
                    .IsRequired();
            });

            //Beneficiary Table
            modelBuilder.Entity<Beneficiary>()
              .HasOne(n => n.Customer)
              .WithMany(n => n.Beneficiaries)
              .HasForeignKey(n => n.CustomerID)
              .HasConstraintName("FK_Beneficiary_Customer");
           
            modelBuilder.Entity<Beneficiary>(entity =>
            {
                entity.HasKey(b => b.BeneficiaryID);
                entity.Property(b => b.BeneficiaryName)
                    .IsRequired() 
                    .HasMaxLength(20);
                entity.Property(b => b.CustomerID)
                    .IsRequired();
                entity.HasIndex(b => b.PhoneNumber);
                entity.Property(b => b.PhoneNumber).HasMaxLength(15).IsRequired();
                entity.Property(b => b.IsActive)
                    .HasDefaultValue(true);
                entity.HasIndex(b => b.PhoneNumber).IsUnique();
            });

            //Top up Table
            modelBuilder.Entity<TopupOption>(entity =>
            {
                entity.Property(o => o.Value)
                .HasColumnType("decimal(18,2)")
                .IsRequired();
                entity.Property(b => b.OptionName)
                   .IsRequired();
            });


           

//Topup Transaction Table
            modelBuilder.Entity<TopupTransaction>()
                .HasOne(t => t.TopupOption)
                .WithMany(tp => tp.TopupTransactions)
                .HasForeignKey(t => t.TopupOptionID)
                .HasConstraintName("FK_TopupTransaction_TopupOption")
                .OnDelete(DeleteBehavior.Restrict); ;

            modelBuilder.Entity<TopupTransaction>()
                .HasOne(t => t.Customer)
                .WithMany(c => c.TopupTransactions)
                .HasForeignKey(t => t.CustomerID)
                .HasConstraintName("FK_TopupTransaction_Customer")
                .OnDelete(DeleteBehavior.Restrict); 

            modelBuilder.Entity<TopupTransaction>()
                .HasOne(t => t.Beneficiary)
                .WithMany(b => b.TopupTransactions)
                .HasForeignKey(t => t.BeneficiaryID)
                .HasConstraintName("FK_TopupTransaction_Beneficiary")
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<TopupTransaction>()
              .Property(o => o.TotalAmount)
              .HasColumnType("decimal(18,2)")
              .IsRequired();
            modelBuilder.Entity<TopupTransaction>()
                .Property(o => o.TopupOptionID)
                .IsRequired();
            modelBuilder.Entity<TopupTransaction>()
                .Property(o => o.CustomerID)
                .IsRequired();
            modelBuilder.Entity<TopupTransaction>()
                .Property(o => o.BeneficiaryID)
                .IsRequired();
            modelBuilder.Entity<TopupTransaction>()
                .Property(t => t.TransactionDate)
                .HasDefaultValueSql("GETUTCDATE()");
            modelBuilder.Entity<TopupTransaction>()
                .Property(o => o.Status)
                .IsRequired();
        }
    }
}
