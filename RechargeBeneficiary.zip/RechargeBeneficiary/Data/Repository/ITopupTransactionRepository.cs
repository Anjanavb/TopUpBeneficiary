﻿using RechargeBeneficiary.Data.Dto;
using RechargeBeneficiary.Model;

namespace RechargeBeneficiary.Data.Repository
{
    public interface ITopupTransactionRepository
    {
        Task<TransactionResponseDto> PostTopupTransaction(TopupTransaction transaction);
        Task<Decimal> TotalRechargeAmountForMonthByBeneficiaryID(int customerID, int beneficiaryID);
        Task<Decimal> TotalRechargeAmountForMonth(int customerID);
    }
}
