﻿using Microsoft.EntityFrameworkCore;
using RechargeBeneficiary.Model;
using System.CodeDom;

namespace RechargeBeneficiary.Data.Repository
{
    public class TopupRepository : ITopupOptionRepository
    {
        private readonly TopUpDBContext _dbContext;
        public TopupRepository(TopUpDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<List<TopupOption>> GetTopupOptions()
        {
            return await _dbContext.TopupOptions.ToListAsync();
        }
        public async Task<TopupOption> GetTopupOptionsById(int id)
        {
            return await _dbContext.TopupOptions.Where(n => n.TopupOptionId == id).FirstOrDefaultAsync();
        }
    }
}
