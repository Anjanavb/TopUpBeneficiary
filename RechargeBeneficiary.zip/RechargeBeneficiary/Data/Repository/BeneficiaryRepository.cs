﻿using Microsoft.EntityFrameworkCore;
using RechargeBeneficiary.Model;

namespace RechargeBeneficiary.Data.Repository
{
    public class BeneficiaryRepository : IBeneficiaryRepository
    {
        private readonly TopUpDBContext _dbContext;
        public BeneficiaryRepository(TopUpDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        //To get all the beneficiary for the customer
        public async Task<List<Beneficiary>> GetAllBeneficiary(int customerID)
        {
            try
            {
                return await _dbContext.Beneficiaries.Where(n => n.CustomerID == customerID && n.IsActive == true).ToListAsync();
            }
            catch (Exception ex) { throw; }
        }
        public async Task<Beneficiary> CreateBeneficiary(Beneficiary beneficiary)
        {
            try
            {
                await _dbContext.Beneficiaries.AddAsync(beneficiary);
                await _dbContext.SaveChangesAsync();
            return beneficiary;
            }
            catch (ArgumentNullException ex)
            {
                throw;
            }
            catch (DbUpdateException ex)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public async Task<Beneficiary> GetBeneficiaryById(int beneficiaryID)
        {
            try
            {
                return await _dbContext.Beneficiaries.Where(n => n.BeneficiaryID == beneficiaryID).FirstOrDefaultAsync();
            }
            catch (Exception ex) { throw; }
        }
        public async Task<int> GetActiveBeneficiariesCount(int customerID)
        {
            try
            {
             var count= await _dbContext.Beneficiaries
            .Where(n => n.CustomerID == customerID && n.IsActive)
            .CountAsync();
             return count;
            }
            catch (Exception ex) { throw; }
        }
        public async Task<bool> IsBeneficiaryPhNumberExist(string phoneNumber, int customerID)
        {
            try
            {
               return await _dbContext.Beneficiaries
             .Where(n => n.PhoneNumber == phoneNumber && n.CustomerID == customerID && n.IsActive)
             .AnyAsync();
            }
            catch (Exception ex) { throw; }
        }
    }
}
