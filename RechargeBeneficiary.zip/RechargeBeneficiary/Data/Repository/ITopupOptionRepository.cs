﻿using Microsoft.AspNetCore.Mvc;
using RechargeBeneficiary.Model;

namespace RechargeBeneficiary.Data.Repository
{
    public interface ITopupOptionRepository
    {
        Task<List<TopupOption>> GetTopupOptions();
        Task<TopupOption> GetTopupOptionsById(int id);
    }
}
