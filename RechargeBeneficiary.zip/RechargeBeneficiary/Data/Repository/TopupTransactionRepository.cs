﻿using Microsoft.EntityFrameworkCore;
using RechargeBeneficiary.Data.Dto;
using RechargeBeneficiary.Model;

namespace RechargeBeneficiary.Data.Repository
{
    public class TopupTransactionRepository : ITopupTransactionRepository
    {
        private readonly TopUpDBContext _dbContext;
        public TopupTransactionRepository(TopUpDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<TransactionResponseDto> PostTopupTransaction(TopupTransaction transaction)
        {

            await _dbContext.TopupTransactions.AddAsync(transaction);
            await _dbContext.SaveChangesAsync();
            return new TransactionResponseDto
            {
                TransactionId = transaction.TransactionId,
                CustomerID = transaction.CustomerID,
                BeneficiaryID = transaction.BeneficiaryID,
                TopupOptionID = transaction.TopupOptionID,
                TotalAmount = transaction.TotalAmount,
                TransactionDate = transaction.TransactionDate,
                Status = transaction.Status,
                AdditionalCharge = 1.00m
            };
        }
        public async Task<Decimal> TotalRechargeAmountForMonthByBeneficiaryID(int customerID, int beneficiaryID)
        {
            DateTime now = DateTime.Now;
            int currentYear = now.Year;
            int currentMonth = now.Month;
            var totalAmountForCurrentMonthforBen = await _dbContext.TopupTransactions
                .Where(t => t.TransactionDate.Year == currentYear
                        && t.TransactionDate.Month == currentMonth
                        && t.CustomerID==customerID
                        && t.BeneficiaryID==beneficiaryID)
                .SumAsync(t => t.TotalAmount);
            return totalAmountForCurrentMonthforBen;
        }
        public async Task<Decimal> TotalRechargeAmountForMonth(int customerID)
        {
            DateTime now = DateTime.Now;
            int currentYear = now.Year;
            int currentMonth = now.Month;
            var totalAmountForCurrentMonth = await _dbContext.TopupTransactions
                .Where(t => t.TransactionDate.Year == currentYear
                        && t.TransactionDate.Month == currentMonth
                        && t.CustomerID == customerID)
                .SumAsync(t => t.TotalAmount);
            return totalAmountForCurrentMonth;
        }
    }
}
