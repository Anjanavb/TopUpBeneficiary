﻿using RechargeBeneficiary.Model;

namespace RechargeBeneficiary.Data.Repository
{
    public interface IBeneficiaryRepository
    {
        Task<List<Beneficiary>> GetAllBeneficiary(int customerID);
        Task<Beneficiary> GetBeneficiaryById(int beneficiaryID);
        Task<Beneficiary>CreateBeneficiary(Beneficiary beneficiary);
        Task<int> GetActiveBeneficiariesCount(int customerID);
        Task<bool> IsBeneficiaryPhNumberExist(string phoneNumber, int customerID);
    }
}
