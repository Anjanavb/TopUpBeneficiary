﻿using Microsoft.EntityFrameworkCore;
using RechargeBeneficiary.Model;

namespace RechargeBeneficiary.Data.Repository
{
    public class CustomerRepository : ICustomerRepository
    {
        private readonly TopUpDBContext _dbContext;
        public CustomerRepository(TopUpDBContext dbContext)
        {
            _dbContext=dbContext;
        }
        public async Task<List<Customer>> GetAll()
        {
            return await _dbContext.Customers.
                  Include(n => n.Beneficiaries).ToListAsync();
        }
        public async Task<Customer> GetById(int id)
        {
            return await _dbContext.Customers.
                Include(n => n.Beneficiaries).Where(n => n.CustomerID == id).FirstOrDefaultAsync();
        }
        public async Task<Customer> CreateCustomer(Customer customer)
        {
            await _dbContext.Customers.AddAsync(customer);
            await _dbContext.SaveChangesAsync();
            return customer;
        }
        public async Task<bool> IsValidCustomer(int customerID)
        {
            return  await _dbContext.Customers.AnyAsync(n => n.CustomerID == customerID);
        }
        public async Task<bool> IsVerifiedCustomer(int customerID)
        {
            return await _dbContext.Customers.AnyAsync(n => n.CustomerID == customerID && n.IsVerified);
        }




    }
}
