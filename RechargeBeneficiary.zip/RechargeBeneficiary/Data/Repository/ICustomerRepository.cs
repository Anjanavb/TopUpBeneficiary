﻿using RechargeBeneficiary.Model;

namespace RechargeBeneficiary.Data.Repository
{
    public interface ICustomerRepository
    {
        Task<List<Customer>> GetAll();
        Task<Customer> GetById(int id);
        Task<bool> IsValidCustomer(int customerID);
        Task<bool> IsVerifiedCustomer(int customerID);
        Task<Customer> CreateCustomer(Customer customer);
    }
}
