﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace RechargeBeneficiary.Migrations
{
    /// <inheritdoc />
    public partial class init : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Customers",
                columns: table => new
                {
                    CustomerID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CustomerName = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    AccountID = table.Column<int>(type: "int", nullable: false),
                    PhoneNumber = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: false),
                    IsVerified = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customers", x => x.CustomerID);
                });

            migrationBuilder.CreateTable(
                name: "TopupOptions",
                columns: table => new
                {
                    TopupOptionId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OptionName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Value = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TopupOptions", x => x.TopupOptionId);
                });

            migrationBuilder.CreateTable(
                name: "Beneficiaries",
                columns: table => new
                {
                    BeneficiaryID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    BeneficiaryName = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    PhoneNumber = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: false),
                    CustomerID = table.Column<int>(type: "int", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Beneficiaries", x => x.BeneficiaryID);
                    table.ForeignKey(
                        name: "FK_Beneficiary_Customer",
                        column: x => x.CustomerID,
                        principalTable: "Customers",
                        principalColumn: "CustomerID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TopupTransactions",
                columns: table => new
                {
                    TransactionId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TopupOptionID = table.Column<int>(type: "int", nullable: false),
                    CustomerID = table.Column<int>(type: "int", nullable: false),
                    BeneficiaryID = table.Column<int>(type: "int", nullable: false),
                    TotalAmount = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    TransactionDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    Status = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TopupTransactions", x => x.TransactionId);
                    table.ForeignKey(
                        name: "FK_TopupTransaction_Beneficiary",
                        column: x => x.BeneficiaryID,
                        principalTable: "Beneficiaries",
                        principalColumn: "BeneficiaryID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_TopupTransaction_Customer",
                        column: x => x.CustomerID,
                        principalTable: "Customers",
                        principalColumn: "CustomerID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_TopupTransaction_TopupOption",
                        column: x => x.TopupOptionID,
                        principalTable: "TopupOptions",
                        principalColumn: "TopupOptionId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                table: "Customers",
                columns: new[] { "CustomerID", "AccountID", "CustomerName", "IsVerified", "PhoneNumber" },
                values: new object[,]
                {
                    { 1, 1, "CustomerA", true, "971100000000" },
                    { 2, 2, "CustomerB", true, "9712000000000" },
                    { 3, 3, "CustomerC", true, "9713000000000" },
                    { 4, 4, "CustomerD", true, "9714000000000" },
                    { 5, 5, "CustomerE", false, "9715000000000" },
                    { 6, 6, "CustomerF", false, "9716000000000" }
                });

            migrationBuilder.InsertData(
                table: "TopupOptions",
                columns: new[] { "TopupOptionId", "OptionName", "Value" },
                values: new object[,]
                {
                    { 1, "AED 5", 5m },
                    { 2, "AED 10", 10m },
                    { 3, "AED 20", 20m },
                    { 4, "AED 30", 30m },
                    { 5, "AED 50", 50m },
                    { 6, "AED 75", 75m },
                    { 7, "AED 100", 100m }
                });

            migrationBuilder.InsertData(
                table: "Beneficiaries",
                columns: new[] { "BeneficiaryID", "BeneficiaryName", "CustomerID", "IsActive", "PhoneNumber" },
                values: new object[,]
                {
                    { 1, "BeneficiaryA1", 1, true, "971000000001" },
                    { 2, "BeneficiaryB1", 2, true, "972000000001" },
                    { 3, "BeneficiaryB2", 2, true, "972000000002" },
                    { 4, "BeneficiaryB3", 2, true, "972000000003" },
                    { 5, "BeneficiaryB4", 2, true, "972000000004" },
                    { 6, "BeneficiaryB5", 2, true, "972000000005" },
                    { 7, "BeneficiaryC1", 3, true, "973000000001" },
                    { 8, "BeneficiaryD1", 4, true, "974000000001" },
                    { 9, "BeneficiaryD2", 4, true, "974000000002" },
                    { 10, "BeneficiaryE1", 5, true, "975000000001" },
                    { 11, "BeneficiaryF1", 6, true, "976000000001" },
                    { 12, "BeneficiaryF2", 6, true, "976000000002" },
                    { 13, "BeneficiaryF3", 6, true, "976000000003" },
                    { 14, "BeneficiaryF4", 6, true, "976000000004" },
                    { 15, "BeneficiaryF5", 6, true, "976000000005" }
                });

            migrationBuilder.InsertData(
                table: "TopupTransactions",
                columns: new[] { "TransactionId", "BeneficiaryID", "CustomerID", "Status", "TopupOptionID", "TotalAmount", "TransactionDate" },
                values: new object[,]
                {
                    { 1, 8, 4, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4262) },
                    { 2, 8, 4, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4266) },
                    { 3, 8, 4, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4268) },
                    { 4, 8, 4, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4269) },
                    { 5, 10, 5, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4271) },
                    { 6, 10, 5, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4273) },
                    { 7, 10, 5, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4274) },
                    { 8, 10, 5, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4276) },
                    { 9, 10, 5, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4277) },
                    { 10, 10, 5, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4279) },
                    { 11, 10, 5, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4280) },
                    { 12, 10, 5, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4282) },
                    { 13, 10, 5, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4283) },
                    { 14, 10, 5, "Success", 5, 51m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4285) },
                    { 15, 11, 6, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4286) },
                    { 16, 11, 6, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4287) },
                    { 17, 11, 6, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4288) },
                    { 18, 11, 6, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4291) },
                    { 19, 11, 6, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4293) },
                    { 20, 11, 6, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4294) },
                    { 21, 11, 6, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4295) },
                    { 22, 11, 6, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4297) },
                    { 23, 11, 6, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4298) },
                    { 24, 12, 6, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4300) },
                    { 25, 12, 6, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4301) },
                    { 26, 12, 6, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4302) },
                    { 27, 12, 6, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4304) },
                    { 28, 12, 6, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4305) },
                    { 29, 12, 6, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4306) },
                    { 30, 12, 6, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4308) },
                    { 31, 12, 6, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4309) },
                    { 32, 12, 6, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4310) },
                    { 33, 13, 6, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4312) },
                    { 34, 13, 6, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4314) },
                    { 35, 13, 6, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4315) },
                    { 36, 13, 6, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4317) },
                    { 37, 13, 6, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4319) },
                    { 38, 13, 6, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4321) },
                    { 39, 13, 6, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4323) },
                    { 40, 13, 6, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4324) },
                    { 41, 13, 6, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4325) },
                    { 42, 14, 6, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4326) },
                    { 43, 14, 6, "Success", 7, 101m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4328) },
                    { 44, 14, 6, "Success", 5, 51m, new DateTime(2024, 7, 28, 17, 30, 45, 272, DateTimeKind.Utc).AddTicks(4329) }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Beneficiaries_CustomerID",
                table: "Beneficiaries",
                column: "CustomerID");

            migrationBuilder.CreateIndex(
                name: "IX_Beneficiaries_PhoneNumber",
                table: "Beneficiaries",
                column: "PhoneNumber",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_TopupTransactions_BeneficiaryID",
                table: "TopupTransactions",
                column: "BeneficiaryID");

            migrationBuilder.CreateIndex(
                name: "IX_TopupTransactions_CustomerID",
                table: "TopupTransactions",
                column: "CustomerID");

            migrationBuilder.CreateIndex(
                name: "IX_TopupTransactions_TopupOptionID",
                table: "TopupTransactions",
                column: "TopupOptionID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "TopupTransactions");

            migrationBuilder.DropTable(
                name: "Beneficiaries");

            migrationBuilder.DropTable(
                name: "TopupOptions");

            migrationBuilder.DropTable(
                name: "Customers");
        }
    }
}
