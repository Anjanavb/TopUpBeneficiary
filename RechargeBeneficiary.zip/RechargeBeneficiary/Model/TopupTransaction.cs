﻿using System.ComponentModel.DataAnnotations;

namespace RechargeBeneficiary.Model
{
    public class TopupTransaction
    {
        [Key]
        public int TransactionId { get; set; }
        public int TopupOptionID { get; set; }
        public int CustomerID { get; set; }
        public int BeneficiaryID { get; set; }
        public decimal TotalAmount { get; set; }
        public DateTime TransactionDate { get; set; } = DateTime.UtcNow;
        public string Status { get; set; }

        
        public TopupOption TopupOption { get; set; }
        public Customer Customer { get; set; }
        public Beneficiary Beneficiary { get; set; }
    }
}
