﻿namespace RechargeBeneficiary.Model.ExternalAPI
{
    public class AccountBalanceResponse
    {
        public decimal AccountBalance { get; set; }
    }
}
