﻿namespace RechargeBeneficiary.Model.ExternalAPI
{
    public class TransactionResponse
    {
        public int TransactionId { get; set; }
        public int CustomerID { get; set; }
        public int BeneficiaryID { get; set; }
        public int TopupOptionID { get; set; }
        public decimal TotalAmount { get; set; }
        public DateTime TransactionDate { get; set; }
        public string Status { get; set; }
        public decimal AdditionalCharge { get; set; }
    }
}
