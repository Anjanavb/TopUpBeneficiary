﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace RechargeBeneficiary.Model
{
    public class Customer
    {
        [Key]
        public int CustomerID { get; set; }
        public string CustomerName { get; set; }

        public int AccountID { get; set; }
        public string PhoneNumber { get; set; }=string.Empty;
        public bool IsVerified { get; set; }
        public List<Beneficiary> Beneficiaries { get; set; }
        public List<TopupTransaction> TopupTransactions { get; set; }
    }
}
