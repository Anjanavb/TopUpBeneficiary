﻿using System.ComponentModel.DataAnnotations;

namespace RechargeBeneficiary.Model
{
    public class Beneficiary
    {
        [Key]
        public int BeneficiaryID { get; set; }
        public string BeneficiaryName { get; set; }
        public string PhoneNumber {  get; set; }
        public int CustomerID { get; set; }
        public bool IsActive { get; set; } = true;

        public Customer Customer { get; set; }
        public List<TopupTransaction> TopupTransactions { get; set; }
    }
}
