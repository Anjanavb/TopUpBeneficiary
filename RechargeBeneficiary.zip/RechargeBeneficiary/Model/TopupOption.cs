﻿using System.ComponentModel.DataAnnotations;

namespace RechargeBeneficiary.Model
{
    public class TopupOption
    {
        [Key]
        public int TopupOptionId { get; set; }
        public string OptionName { get; set; }
        public decimal Value { get; set; }
        public List<TopupTransaction> TopupTransactions { get; set; }
    }
}
